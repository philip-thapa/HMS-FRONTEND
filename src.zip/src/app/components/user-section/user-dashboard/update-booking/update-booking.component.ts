import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-booking',
  templateUrl: './update-booking.component.html',
  styleUrls: ['./update-booking.component.css']
})
export class UpdateBookingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
