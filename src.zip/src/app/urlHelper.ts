export const baseUrl:string = "http://localhost:8000/hms/";

export const imageUrl: string = "http://localhost:8000";